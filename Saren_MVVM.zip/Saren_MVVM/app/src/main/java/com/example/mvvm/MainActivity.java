package com.example.mvvm;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class MainActivity extends AppCompatActivity {
    private GuitarViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView rv = findViewById(R.id.recyclerview);
        rv.setLayoutManager(new LinearLayoutManager(this));

        viewModel = new ViewModelProvider(this).get(GuitarViewModel.class);

        viewModel.getGuitars().observe(this, list -> {
            rv.setAdapter(new GuitarAdapter(list, position -> {
                viewModel.deleteGuitar(position);
            }));
        });
    }
}