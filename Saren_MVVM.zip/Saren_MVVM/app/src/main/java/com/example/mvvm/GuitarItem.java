package com.example.mvvm;

public class GuitarItem {
    private int image;
    private String name, price, description;

    public GuitarItem(int image, String name, String price, String description) {
        this.image = image;
        this.name = name;
        this.price = price;
        this.description = description;
    }

    public int getImage() { return image; }
    public String getName() { return name; }
    public String getPrice() { return price; }
    public String getDescription() { return description; }
}