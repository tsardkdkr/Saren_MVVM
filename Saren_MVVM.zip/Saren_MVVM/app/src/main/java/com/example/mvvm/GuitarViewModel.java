package com.example.mvvm;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import java.util.ArrayList;
import java.util.List;

public class GuitarViewModel extends ViewModel {
    private MutableLiveData<List<GuitarItem>> guitarList;

    public LiveData<List<GuitarItem>> getGuitars() {
        if (guitarList == null) {
            guitarList = new MutableLiveData<>();
            loadInitialGuitars();
        }
        return guitarList;
    }

    private void loadInitialGuitars() {
        List<GuitarItem> list = new ArrayList<>();
        list.add(new GuitarItem(R.drawable.fender_telecaster_green, "SurfGreen Tele", "P11,000", "Vintage 50s Style"));
        list.add(new GuitarItem(R.drawable.vintage_bench_test__1963_gibson_sg_les_paul_standard, "Gibson SG", "P9,000", "1963 Classic Rocker"));
        list.add(new GuitarItem(R.drawable.________, "Red Stratocaster", "P20,000", "Custom Shop Edition"));
        guitarList.setValue(list);
    }

    public void deleteGuitar(int position) {
        List<GuitarItem> current = new ArrayList<>(guitarList.getValue());
        if (position >= 0 && position < current.size()) {
            current.remove(position);
            guitarList.setValue(current);
        }
    }
}