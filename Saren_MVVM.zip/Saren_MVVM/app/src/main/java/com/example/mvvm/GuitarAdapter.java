package com.example.mvvm;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class GuitarAdapter extends RecyclerView.Adapter<GuitarViewHolder> {
    private List<GuitarItem> items;
    private OnDeleteClickListener listener;

    public interface OnDeleteClickListener { void onDelete(int position); }

    public GuitarAdapter(List<GuitarItem> items, OnDeleteClickListener listener) {
        this.items = items;
        this.listener = listener;
    }

    @NonNull
    @Override
    public GuitarViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new GuitarViewHolder(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.items, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull GuitarViewHolder holder, int position) {
        GuitarItem item = items.get(position);
        holder.imageView.setImageResource(item.getImage());
        holder.name.setText(item.getName());
        holder.price.setText(item.getPrice());
        holder.description.setText(item.getDescription());

        holder.btnAction.setOnClickListener(v -> listener.onDelete(position));
    }

    @Override
    public int getItemCount() { return items.size(); }
}