package com.example.mvvm;

import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class GuitarViewHolder extends RecyclerView.ViewHolder {
    ImageView imageView;
    TextView name, price, description;
    ImageButton btnAction;

    public GuitarViewHolder(@NonNull View itemView) {
        super(itemView);
        imageView = itemView.findViewById(R.id.imgProduct);
        name = itemView.findViewById(R.id.txtName);
        price = itemView.findViewById(R.id.txtPrice);
        description = itemView.findViewById(R.id.txtDescription);
        btnAction = itemView.findViewById(R.id.btnAction);
    }
}